client\_storage module
======================

.. automodule:: client_storage
   :members:
   :undoc-members:
   :show-inheritance:
