server\_gui module
==================

.. automodule:: server_gui
   :members:
   :undoc-members:
   :show-inheritance:
