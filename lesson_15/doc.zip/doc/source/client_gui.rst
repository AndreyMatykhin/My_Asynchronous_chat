client\_gui module
==================

.. automodule:: client_gui
   :members:
   :undoc-members:
   :show-inheritance:
