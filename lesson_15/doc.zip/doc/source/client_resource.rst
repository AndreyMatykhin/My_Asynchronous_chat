client\_resource module
=======================

.. automodule:: client_resource
   :members:
   :undoc-members:
   :show-inheritance:
